# 🌳 Minimum Spanning Tree Visualizer

A beautiful, interactive web-based visualizer for comparing **Kruskal's** and **Prim's** algorithms side-by-side.

## 🎯 Features

- ✨ **Interactive Visualization** - See both algorithms work simultaneously
- 📊 **Real-time Comparison** - Compare performance and results
- 🎨 **Beautiful Design** - Modern UI with gradient backgrounds
- 📱 **Fully Responsive** - Works on desktop and mobile devices
- ⚡ **Instant Feedback** - Real-time steps and statistics
- 🔄 **Multiple Examples** - Pre-loaded graph examples
- 🎲 **Random Graph Generator** - Generate custom test cases

## 🚀 Live Demo

Visit: **[https://YOUR_USERNAME.github.io/mst-visualizer/](https://YOUR_USERNAME.github.io/mst-visualizer/)**

## 📚 What are Spanning Trees?

A **Minimum Spanning Tree (MST)** is a tree that connects all vertices of a weighted graph with the minimum total edge weight.

### Kruskal's Algorithm
- **Approach**: Greedy
- **Strategy**: Sort edges by weight, add them if they don't create a cycle
- **Time Complexity**: O(E log E)
- **Uses**: Union-Find data structure

### Prim's Algorithm
- **Approach**: Greedy
- **Strategy**: Start from a vertex, repeatedly add the minimum weight edge
- **Time Complexity**: O(V²)
- **Uses**: Priority queue or adjacency list

## 🎮 How to Use

1. **Generate a Graph**
   - Click "Random Graph" or load an example
   - Adjust node count if needed

2. **Visualize**
   - See how each algorithm builds the MST
   - Green edges = selected for MST
   - Gray edges = not selected

3. **Compare**
   - Both algorithms find the same total weight ✓
   - But they may follow different paths
   - Compare the steps taken

## 🛠️ Installation

### Option 1: Direct Online Use
Just open the deployed site - no installation needed!

### Option 2: Local Development

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/mst-visualizer.git
cd mst-visualizer

# Start a local server (Python 3)
python -m http.server 8000

# Or using Node.js
npx http-server

# Visit http://localhost:8000
```

## 📁 Project Structure

```
mst-visualizer/
├── index.html          # Main application
├── README.md           # This file
└── assets/            # (Optional) Images and resources
```

## 💡 How It Works

### Algorithm Implementation

**Kruskal's Algorithm:**
1. Sort all edges by weight
2. Use Union-Find to detect cycles
3. Add edge if it doesn't create a cycle
4. Continue until all nodes are connected

**Prim's Algorithm:**
1. Start with one vertex
2. Find minimum weight edge from visited to unvisited
3. Add that edge and mark new vertex as visited
4. Repeat until all vertices are connected

### Data Structures

- **Graph**: Nodes and weighted edges
- **Union-Find**: For cycle detection in Kruskal's
- **Canvas API**: For visualization

## 🎨 Customization

### Change Colors
Edit the CSS gradient in `index.html`:
```css
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
```

### Adjust Canvas Size
Modify canvas container height:
```css
.canvas-container {
    height: 400px; /* Change this */
}
```

### Add More Examples
Add functions like `loadExample4()` in the script section.

## 📊 Algorithm Comparison Table

| Feature | Kruskal | Prim |
|---------|---------|------|
| Sorting | Required | Not required |
| Data Structure | Union-Find | Priority Queue |
| Time | O(E log E) | O(V²) |
| Best for | Sparse graphs | Dense graphs |
| Conceptually | Global view | Local view |

## 🐛 Known Limitations

- Maximum ~10 nodes for clarity
- Weights must be positive integers
- Undirected graphs only
- Canvas-based rendering

## 🚀 Future Enhancements

- [ ] Add Borůvka's algorithm
- [ ] Save/load graphs as JSON
- [ ] Step-by-step animation
- [ ] Performance benchmarking
- [ ] Dark mode theme
- [ ] Mobile touch support for drawing

## 📝 License

This project is open source under the [MIT License](LICENSE).

## 🤝 Contributing

Found a bug? Have an idea? Feel free to:
1. Open an issue
2. Submit a pull request
3. Provide feedback

## 📧 Contact

Created with ❤️ for algorithm lovers

---

### 📚 Resources

- [Kruskal's Algorithm - GeeksforGeeks](https://www.geeksforgeeks.org/kruskals-minimum-spanning-tree-algorithm-greedy-algo-2/)
- [Prim's Algorithm - Wikipedia](https://en.wikipedia.org/wiki/Prim%27s_algorithm)
- [Minimum Spanning Tree](https://en.wikipedia.org/wiki/Minimum_spanning_tree)

---

**Enjoy visualizing! 🌳✨**
