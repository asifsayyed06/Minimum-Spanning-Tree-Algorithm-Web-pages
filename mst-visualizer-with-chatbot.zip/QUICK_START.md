# ⚡ QUICK START - Deploy in 5 Minutes

## Step 1️⃣: Create Repository
```
Go to: github.com/new
Name: mst-visualizer
Make it PUBLIC ✓
Click "Create repository"
```

## Step 2️⃣: Upload Files

**Easiest Way (Web UI):**
1. Click "Add file" → "Upload files"
2. Drag `mst-visualizer.html`
3. Rename it to `index.html`
4. Click "Commit changes"

OR **Using Git:**
```bash
git clone https://github.com/YOUR_USERNAME/mst-visualizer.git
cd mst-visualizer
cp mst-visualizer.html index.html
git add index.html
git commit -m "Add MST visualizer"
git push
```

## Step 3️⃣: Enable GitHub Pages
1. Go to Settings → Pages
2. Source: Deploy from a branch
3. Branch: main
4. Folder: / (root)
5. Click Save

## Step 4️⃣: Wait & Share
```
Wait 1-2 minutes for GitHub to build...

Your site: https://YOUR_USERNAME.github.io/mst-visualizer/
```

## Step 5️⃣: (Optional) Add README
1. Create `README.md` file
2. Paste content from README.md
3. Commit & Push

---

## 📁 Final Folder Layout (What GitHub Sees)

```
Your Repository
├── index.html          ← Main file (REQUIRED)
├── README.md          ← Documentation (Optional)
└── (That's it!)
```

---

## ✅ Verification Checklist

- [ ] Repository created & public
- [ ] index.html uploaded
- [ ] GitHub Pages enabled
- [ ] Site is live at https://YOUR_USERNAME.github.io/mst-visualizer/
- [ ] Click "Random Graph" button works
- [ ] Algorithms compare correctly

---

## 🎯 What You Get

```
┌─────────────────────────────────────────┐
│   Your Live MST Visualizer Website      │
│                                         │
│  Kruskal              │  Prim          │
│  Algorithm            │  Algorithm     │
│  (Canvas)             │  (Canvas)      │
│  Stats & Steps        │  Stats & Steps │
│                                         │
│  Controls: Random/Clear/Examples        │
└─────────────────────────────────────────┘
```

---

## 🐛 Troubleshooting

| Problem | Solution |
|---------|----------|
| Site won't load | Wait 2 min, clear cache, repo must be PUBLIC |
| 404 error | Make sure `index.html` is in root, not in folder |
| Styling broken | GitHub might be building, wait & refresh |
| Algorithms don't run | Open browser console (F12) for errors |

---

## 🎨 Quick Customizations

### Change Title
In `index.html`, find:
```html
<title>Minimum Spanning Tree Visualizer</title>
```
Change to:
```html
<title>My Cool MST Visualizer</title>
```

### Change Colors
Find this in CSS:
```css
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
```

Colors you can try:
- Blue→Pink: `#3498db 0%, #e74c3c 100%`
- Green→Teal: `#2ecc71 0%, #1abc9c 100%`
- Orange→Red: `#f39c12 0%, #e74c3c 100%`

### Add GitHub Link
In the header, find:
```html
<div class="header">
    <h1>🌳 Minimum Spanning Tree Visualizer</h1>
```

Add after h1:
```html
<p>📚 <a href="https://github.com/YOUR_USERNAME/mst-visualizer" style="color: white;">View on GitHub</a></p>
```

---

## 🚀 You're Done!
Share your link: `https://YOUR_USERNAME.github.io/mst-visualizer/`

**Questions?** Check GITHUB_PAGES_SETUP.md for detailed guide.
