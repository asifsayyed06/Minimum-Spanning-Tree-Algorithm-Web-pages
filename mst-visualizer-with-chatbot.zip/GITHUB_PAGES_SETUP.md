# 🚀 Deploy MST Visualizer on GitHub Pages

## Folder Structure

```
your-repo-name/
│
├── index.html                 (Main page - rename your mst-visualizer.html to this)
├── README.md                  (Project description)
├── css/
│   └── style.css             (Optional: separate CSS file)
├── js/
│   └── script.js             (Optional: separate JavaScript file)
└── assets/
    └── logo.png              (Optional: images/screenshots)
```

## Quick Setup (3 Steps)

### Step 1: Create GitHub Repository

1. Go to [github.com/new](https://github.com/new)
2. Create a repository named: `mst-visualizer` (or any name you like)
3. Make it **Public**
4. Click "Create repository"

### Step 2: Upload Files

**Option A - Using GitHub Web Interface (Easiest)**

1. Click "Add file" → "Upload files"
2. Drag and drop the `mst-visualizer.html` file
3. Rename it to `index.html` in GitHub
4. Click "Commit changes"

**Option B - Using Git Command Line**

```bash
# Clone your new repository
git clone https://github.com/YOUR_USERNAME/mst-visualizer.git
cd mst-visualizer

# Copy the file
cp path/to/mst-visualizer.html index.html

# Push to GitHub
git add index.html
git commit -m "Initial commit: Add MST visualizer"
git push origin main
```

### Step 3: Enable GitHub Pages

1. Go to your repository settings
2. Scroll to "GitHub Pages" section
3. Select "Deploy from a branch"
4. Choose branch: `main` (or `master`)
5. Select folder: `/ (root)`
6. Click "Save"

✅ **Your site is live at:** `https://YOUR_USERNAME.github.io/mst-visualizer/`

---

## Enhanced Folder Structure (For Advanced Projects)

```
mst-visualizer/
│
├── index.html                 # Main visualizer
├── README.md                  # Project documentation
├── LICENSE                    # MIT or your choice
│
├── css/
│   ├── style.css             # Main styles
│   └── responsive.css        # Mobile styles
│
├── js/
│   ├── graph.js              # Graph class
│   ├── algorithms.js         # Kruskal & Prim algorithms
│   ├── visualization.js      # Canvas drawing
│   └── main.js               # App initialization
│
├── assets/
│   ├── logo.png
│   ├── screenshot.png
│   └── favicon.ico
│
└── examples/
    ├── example1.json
    ├── example2.json
    └── example3.json
```

### Create this structure with commands:

```bash
mkdir -p css js assets examples
touch css/style.css js/script.js
```

---

## File to Split: ALL-IN-ONE to MODULAR

### If you want to separate into multiple files:

#### `js/graph.js`
```javascript
class Graph {
    constructor() {
        this.nodes = [];
        this.edges = [];
    }
    // ... rest of Graph class
}

class UnionFind {
    // ... UnionFind class
}
```

#### `js/algorithms.js`
```javascript
function kruskalMST(graph) {
    // ... Kruskal algorithm
}

function primMST(graph) {
    // ... Prim algorithm
}
```

#### `index.html` - Update `<head>` to:
```html
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minimum Spanning Tree Visualizer</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- ... HTML content -->
    
    <script src="js/graph.js"></script>
    <script src="js/algorithms.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
```

---

## Testing Locally Before Upload

### Simple HTTP Server (Python 3)
```bash
cd your-project-folder
python -m http.server 8000
```
Then open: `http://localhost:8000`

### Simple HTTP Server (Node.js)
```bash
npm install -g http-server
http-server
```

---

## Customization Tips

### Change Colors
In CSS, update gradient colors:
```css
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
/* Change to your preferred colors */
background: linear-gradient(135deg, #FF6B6B 0%, #4ECDC4 100%);
```

### Add Your Logo
```html
<div class="header">
    <img src="assets/logo.png" alt="Logo" style="height: 50px; margin-bottom: 10px;">
    <h1>My MST Visualizer</h1>
</div>
```

### Custom Domain (Optional)
1. Add `CNAME` file to repo with your domain
2. Configure domain DNS settings
3. [GitHub Pages Custom Domain Guide](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site)

---

## Troubleshooting

**Site not showing?**
- Wait 1-2 minutes for GitHub Pages to build
- Check if `index.html` is in root folder
- Make repo is PUBLIC

**Styling not working?**
- Clear browser cache (Ctrl+Shift+Delete)
- Check CSS file path in HTML

**Elements not responsive on mobile?**
- Viewport meta tag is included ✓
- Test with DevTools (F12)

---

## Share Your Project

After deployment:

```markdown
📊 **Minimum Spanning Tree Visualizer**
Compare Kruskal's and Prim's algorithms side-by-side
🔗 https://YOUR_USERNAME.github.io/mst-visualizer/
```

---

## Next Steps

1. ✅ Upload to GitHub
2. ✅ Enable GitHub Pages
3. ✅ Test the link
4. 📝 Add README.md with description
5. 🎨 Customize colors/branding
6. 📤 Share with others!

**Happy visualizing! 🌳**
